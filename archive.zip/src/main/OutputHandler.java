package main;

/**
 *
 * @author s147889
 */
public class OutputHandler {
    String output;

    public OutputHandler(String output) {
        this.output = output;
    }
}
