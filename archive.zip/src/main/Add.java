package main;

/**
 *
 * @author s157710
 */
public class Add extends Operation {

    public Add(BigInt x, BigInt y) {
        super(x, y);
    }

    @Override
    public BigInt compute(){
        
        int size = x.val.length();
        
        return null;
    }
}
