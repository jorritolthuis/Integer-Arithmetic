package main;

import java.util.Scanner;

/**
 *
 * @author s147889
 */
public class InputHandler {
    Scanner scanner;
    String input;

    public InputHandler() {
        scanner = new Scanner(System.in);
        
        createInput(scanner.nextLine());
    }

    private void createInput(String nextLine) {
        
    }
}
